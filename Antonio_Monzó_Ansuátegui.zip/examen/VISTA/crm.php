<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM</title>
</head>
<body>
<h1>El papel de las vacunas en la salud pública</h1>
    <a href="index.php">Registro</a>
    <a href="baja.php">Baja</a>
    <a href="modificacion.php">Modificación de datos</a>
    <a href="crm.php">CRM</a>
   
</body>
</html>

<?php
require_once "../CONTROLADOR/conexion.php";

$conexion = mysqli_connect($host, $usuario, $contraseña, $bbdd);

if (!$conexion) {
    die("Error de conexión a la base de datos" . mysqli_connect_error());
}

$sql_consultar = "SELECT * FROM registroasistentes ORDER BY fecha ASC, hora ASC";
$resultado_consultar = mysqli_query($conexion, $sql_consultar);

if (!$resultado_consultar) {
    die("Error" . mysqli_error($conexion));
}

if (mysqli_num_rows($resultado_consultar) > 0) {
 
    echo "<p>El número total de asistentes es: ". mysqli_num_rows($resultado_consultar)."</p>";
    echo"<h4>Lista de todos los asistentes ordenados por fecha y hora de inscripción ascendente</h4>";
    echo "<table border='1' cellpadding='5' celspacing='0'>";
    echo " <tr><th>email</th>
    <th>Nombre</th>
    <th>Apellido1</th>
    <th>Apellido2</th>
    <th>Centro de trabajo</th>
    <th>Teléfono</th>
    <th>Dirección</th>
    <th>Código postal</th>
    <th>Ciudad</th>
    <th>Provincia</th>
    <th>Fecha</th>
    <th>Hora</th></tr>";
    while ($row = mysqli_fetch_assoc($resultado_consultar)) {
        echo "<tr><td>" . $row['email'] . "</td><td>" . $row['nombre'] . "</td><td>" . $row['apellido1'] . "</td><td>" . $row['apellido2'] . "</td><td>" . $row['centrotrabajo'] . "</td><td>" . $row['telefono'] . "</td><td>" . $row['direccion'] . "</td><td>" . $row['codigopostal'] . "</td><td>" . $row['ciudad'] . "</td><td>" . $row['provincia'] . "</td><td>" . $row['fecha'] . "</td><td>" . $row['hora'] . "</td></tr>";
       
    

    }

    echo "</table >";

   

}else{
    echo "No hay asistentes";
}
echo "<h3> Lista de todos los asistentes por provincia ordenados por total de asistentes descendeste FALTA JOIN </h3>";
echo "<table border='1' cellpadding='5' celspacing='0'>";

$sql_consultar2 = "SELECT provincia, COUNT(email) AS Número FROM registroasistentes GROUP BY provincia ORDER BY Número DESC";
$resultado_consultar2 = mysqli_query($conexion, $sql_consultar2);
 echo " <tr><th>Provincia</th> <th>Número de asistentes</th></tr>";

 
if (mysqli_num_rows($resultado_consultar2) > 0) {
    while ($row = mysqli_fetch_assoc($resultado_consultar2)) {
         echo "<tr><td>" . $row['provincia'] . "</td><td>" . $row['Número'] . "</td><tr>";
    }
}
 