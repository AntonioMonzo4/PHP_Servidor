<?php

$host = "localhost";
$usuario = "juandeherrera";
$contraseña ="IESjdh2025*";
$bbdd = "jornadadevacunacion_examen";

