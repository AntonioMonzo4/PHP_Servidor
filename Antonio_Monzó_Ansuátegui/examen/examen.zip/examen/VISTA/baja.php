<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de baja</title>
</head>
<body>
<h1>El papel de las vacunas en la salud pública</h1>
    <a href="index.php">Registro</a>
    <a href="baja.php">Baja</a>
    <a href="modificacion.php">Modificación de datos</a>
    <a href="crm.php">CRM</a>

    <form action="../MODELO/formularioBaja.php"  method="POST">
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <label for="tlfn">Teléfono</label>
        <input type="tel" name="tlfno" required>
        <input type="submit" value="Darme de baja" name="enviar">
    </form>
    
</body>
</html>